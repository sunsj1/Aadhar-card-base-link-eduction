
<?php

// Inialize session
session_start();

// Delete certain session
//unset($_SESSION['uname']);
unset($_SESSION['id']);
unset($_SESSION['stu_name']);
unset($_SESSION['stu_gender']);
unset($_SESSION['stu_email']);
unset($_SESSION['stu_mobileno']);
unset($_SESSION['stu_par_mobileno']);
unset($_SESSION['stu_dob']);
unset($_SESSION['stu_aadhar_no']);
unset($_SESSION['stu_photo']);
unset($_SESSION['stu_education']);
unset($_SESSION['stu_caste']);
unset($_SESSION['stu_reg_date']);


// Delete all session variables
//session_destroy();

// Jump to login page
echo '<script type="text/javascript">'; 
 
echo 'window.location.href = "index.php";';
echo '</script>'; 
?>
