<?php
if(isset($_POST["pay"])){
    // Capture selected country
   // $type= $_POST["c"];
     $str = $_POST['pay'];
               
     // $con = mysqli_connect("localhost","root","root","drop") or die("Some error occurred during connection " . mysqli_error($con)); 

      include "config.php";

      ?>
     
      <?php   
      //@mysqli_query($con,"SET NAMES 'utf8'",$id);
      $sql='select DISTINCT stu_aadhar_no from student_info where stu_name="'.$str.'"';
       $select=mysqli_query($con,$sql)or die(mysqli_error($con));
     while($sele=mysqli_fetch_array($select))
{
    echo"<option value=\"{$sele['stu_aadhar_no']}\">{$sele['stu_aadhar_no']}</option>";
   


    }   
       
}


?>
