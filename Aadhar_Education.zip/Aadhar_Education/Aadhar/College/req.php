<?php
session_start();

include "config.php";

if( (isset($_GET['id'])) &&(isset($_GET['c_name_transfer'])) ) 
{
	// $req=
	 //extract($_POST);
 $query=mysqli_query($con,"update student_info set
 c_name_transfer='".$_SESSION['c_name']."',
 stu_status='Request'
 where  id='".$_GET['id']."' ") or die(mysqli_error($con));
 	if($query)
    {
       echo '<script type="text/javascript">';
       echo " alert('Request Send Successfully');";
       echo 'window.location.href = "send_request.php";';
       echo '</script>';
    }
    else
    {
  	   echo '<script type="text/javascript">';
       echo "alert('Eror Occured');";
       //die(mysqli_error($con));
       echo 'window.location.href = "send_request.php";';
       echo '<script>';
                        //echo $cQry;
    }
}



?>