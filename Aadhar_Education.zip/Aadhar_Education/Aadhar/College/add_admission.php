<?php
include("start.php");
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>College Admin - Dashboard</title>

		<!-- page specific plugin styles -->
		<link rel="stylesheet" href="assets/css/jquery-ui.custom.min.css" />
		<link rel="stylesheet" href="assets/css/chosen.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-datepicker3.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-timepicker.min.css" />
		<link rel="stylesheet" href="assets/css/daterangepicker.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-colorpicker.min.css" />
		

		<?php
		
		include "header.php";
		
		?>
		
		
		
				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>
			</div>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								School/College
							</li>
							<li class="active">Dashboard</li>
						</ul><!-- /.breadcrumb -->

						<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	
						
					</div>

					<div class="page-content">
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>

							<div class="ace-settings-box clearfix" id="ace-settings-box">
								<div class="pull-left width-50">
									<div class="ace-settings-item">
										<div class="pull-left">
											<select id="skin-colorpicker" class="hide">
												<option data-skin="no-skin" value="#438EB9">#438EB9</option>
												<option data-skin="skin-1" value="#222A2D">#222A2D</option>
												<option data-skin="skin-2" value="#C6487E">#C6487E</option>
												<option data-skin="skin-3" value="#D0D0D0">#D0D0D0</option>
											</select>
										</div>
										<span>&nbsp; Choose Skin</span>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-navbar" autocomplete="off" />
										<label class="lbl" for="ace-settings-navbar"> Fixed Navbar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-sidebar" autocomplete="off" />
										<label class="lbl" for="ace-settings-sidebar"> Fixed Sidebar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-breadcrumbs" autocomplete="off" />
										<label class="lbl" for="ace-settings-breadcrumbs"> Fixed Breadcrumbs</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-rtl" autocomplete="off" />
										<label class="lbl" for="ace-settings-rtl"> Right To Left (rtl)</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-add-container" autocomplete="off" />
										<label class="lbl" for="ace-settings-add-container">
											Inside
											<b>.container</b>
										</label>
									</div>
								</div><!-- /.pull-left -->

								<div class="pull-left width-50">
									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-hover" autocomplete="off"/>
										<label class="lbl" for="ace-settings-hover"> Submenu on Hover</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-compact" autocomplete="off" />
										<label class="lbl" for="ace-settings-compact"> Compact Sidebar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-highlight" autocomplete="off" />
										<label class="lbl" for="ace-settings-highlight"> Alt. Active Item</label>
									</div>
								</div><!-- /.pull-left -->
							</div><!-- /.ace-settings-box -->
						</div><!-- /.ace-settings-container -->

						<div class="page-header">
							<h1>
								School/College
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									Dashboard
								</small>
							</h1>
						</div><!-- /.page-header -->

<?php

										include "config.php";

										if(isset($_POST['submit']))
										{
											extract($_POST);

											date_default_timezone_set("Asia/Kolkata");
											//$RegDate = date('d/m/Y');
											$RegDate = date('Y-m-d');

											$img=md5(time());
										  	$name1=$_FILES['stu_photo']['name'];
											$type=$_FILES['stu_photo']['type'];
											$size=$_FILES['stu_photo']['size'];
											$temp=$_FILES['stu_photo']['tmp_name'];
											$img1="".$img.$name1;
											move_uploaded_file($temp,"Student_Photos/".$img1);

											$queryreg=mysqli_query($con,"insert into student_info (c_name, c_email,stu_name,stu_mother_name,stu_father_name,stu_gender,stu_email,stu_mobileno, stu_par_mobileno,stu_dob,stu_aadhar_no,stu_address,stu_photo,stu_education,stu_caste,stu_reg_date) values ('".$_SESSION['c_name']."','".$_SESSION['c_email']."','$stu_name','$stu_mother_name','$stu_father_name','$stu_gender','$stu_email','$stu_mobileno','$stu_par_mobileno','$stu_dob','$stu_aadhar_no','$stu_address','$img1','$stu_education','$stu_caste','$RegDate')") or die(mysqli_error($con));

											if($queryreg)
											{
												
														echo "<script>";
														echo "alert('New Student Registerd Successfully ');";
														echo "window.location.href='add_admission.php';";
														echo "</script>";																		
											}
											else
											{
												echo "<script>";
												echo 'alert("Student Not Registerd");';
												echo "window.location.href='add_admission.php';";
												echo "</script>";
											}

										}


									?>


								<form class="form-horizontal" role="form" method="post" enctype="multipart/form-data" >
									<h3>Student Basic Details</h3><br>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Name of Student </label>

										<div class="col-sm-9">
											<input type="text" name="stu_name" id="form-field-2" placeholder="Enter Student Name" class="col-xs-10 col-sm-5" required />
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Student Mother Name</label>

										<div class="col-sm-9">
											<input type="text" name="stu_mother_name" id="form-field-2" placeholder="Enter Student Mother Name" class="col-xs-10 col-sm-5" required />
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Student Father Name</label>

										<div class="col-sm-9">
											<input type="text" name="stu_father_name" id="form-field-2" placeholder="Enter Student Father Name" class="col-xs-10 col-sm-5" required />
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Gender </label>

										<div class="col-sm-9">
											<input name="stu_gender" type="radio" value="Male" class="ace" />
														<span class="lbl"> Male </span>
														&nbsp;&nbsp;
											<input name="stu_gender" type="radio" value="Female" class="ace" />
														<span class="lbl"> Female </span>
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>





									<!-- <input name="form-field-radio" type="radio" class="ace" />
														<span class="lbl"> radio option 1</span> -->

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Email </label>

										<div class="col-sm-9">
											<input type="text" name="stu_email" id="form-field-2" placeholder="Enter Email" class="col-xs-10 col-sm-5" required />
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Mobile No </label>

										<div class="col-sm-9">
											<input type="text" name="stu_mobileno" id="form-field-2" placeholder="Enter Mobile No" maxlength="10" pattern="[789][0-9]{9}" class="col-xs-10 col-sm-5" required />
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Parents Mobile No </label>

										<div class="col-sm-9">
											<input type="text" name="stu_par_mobileno" id="form-field-2" placeholder="Enter Mobile No" maxlength="10" pattern="[789][0-9]{9}" class="col-xs-10 col-sm-5"  />
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2"> Date of Birth </label>

										<div class="col-sm-9">
											<!-- <input type="file" name="ownerphoto" id="form-field-2" placeholder="Select Photo For Uploading" class="col-xs-10 col-sm-5" required /> -->

											<div class="input-group">
												<input class="form-control date-picker col-xs-10 col-sm-5 " id="form-field-2" type="text" data-date-format="yyyy-mm-dd" name="stu_dob"  required />
																	<!-- <span class="input-group-addon">
																		<i class="fa fa-calendar bigger-110"></i>
																	</span>-->
 											</div>
											
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Aadhar Card No </label>

										<div class="col-sm-9">
											<input type="text" name="stu_aadhar_no" id="form-field-2" placeholder="Enter Aadhar Card No" maxlength="12" class="col-xs-10 col-sm-5" required />
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Address</label>

										<div class="col-sm-9">
											
											<textarea name="stu_address" id="form-field-2" placeholder="Enter Address of Student" class="col-xs-10 col-sm-5" required ></textarea>
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>	

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2"> Student Photo </label>

										<div class="col-sm-9">
											<input type="file" name="stu_photo" id="form-field-2" placeholder="Select Photo For Uploading" class="col-xs-10 col-sm-5" required />



											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Select Report</span>
											</span> -->
										</div>
									</div>
														

									<br>

									<h3>Educational Details</h3><br>
									<?php

									if($_SESSION['c_type']=="School")
									{
									?>						
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Highest Education</label>

										<div class="col-sm-9">
											<select name="stu_education" class="col-xs-10 col-sm-5" id="form-field-2" required >
                                                    <option value="">Select Education</option>
                                                    <option value="1">1</option> 
                                                    <option value="2">2</option> 
                                                    <option value="3">3</option> 
                                                    <option value="4">4</option> 
                                                    <option value="5">5</option> 
                                                    <option value="6">6</option> 
                                                    <option value="7">7</option> 
                                                    <option value="8">8</option> 
                                                    <option value="9">9</option> 
                                                    <option value="10">10</option> 
                                                            
                                            </select>											
										</div>
									</div>
									<?php
									}
									elseif($_SESSION['c_type']=="College")
									{
									?>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Highest Education</label>

										<div class="col-sm-9">
											<select name="stu_education" class="col-xs-10 col-sm-5" id="form-field-2" required >
                                                    <option value="">Select  Education</option>
                                                    <option value="HSC">HSC</option> 
                                                    <option value="Under Graduate">Under Graduate</option> 
                                                    <option value="Graduate">Graduate</option> 
                                                    <option value="Post Graduate">Post Graduate</option> 
                                                    <option value="BE/B.Tech">BE/B.Tech</option> 
                                                    <option value="ME/B.Tech">ME/M.Tech</option> 
                                                    <option value="MBA">MBA</option> 
                                                    <option value="PHD">PHD</option>         
                                            </select>											
										</div>
									</div>
									<?php
									}
									else
									{ }
									?>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Caste</label>

										<div class="col-sm-9">
											<select name="stu_caste" class="col-xs-10 col-sm-5" id="form-field-2" required >
                                                    <option value="">Select Cast</option>
                                                    <option value="SC">SC</option> 
                                                    <option value="ST">ST</option> 
                                                    <option value="NT">NT</option> 
                                                    <option value="OBC">OBC</option> 
                                                    <option value="Open">Open</option>         
                                                    <option value="Other">Other</option>         
                                            </select>
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>	
									<br>

									
									

									<!-- <div class="form-group">
											<div class="widget-main">
												<label class="col-sm-3 control-label no-padding-right" for="form-field-2"> Report </label>

												<div class="col-sm-9">
													<input type="file" id="id-input-file-2" class="col-xs-10 col-sm-5" required />
												</div>
											</div>
									</div> -->

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<button class="btn btn-info" type="submit" name="submit" >
												<i class="ace-icon fa fa-check bigger-110"></i>
												Submit
											</button>

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									</div>


								</form>

	
								
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->				

								

								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
						<br>
						
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

		<?php

include ('footer_calender.php');

?>
	</body>
</html>
