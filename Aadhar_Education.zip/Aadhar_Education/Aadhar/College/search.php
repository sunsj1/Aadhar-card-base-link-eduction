<?php

	session_start();

?>	

<script src="//code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script  src="https://cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js"></script>
<script  src="//cdn.datatables.net/buttons/1.2.4/js/buttons.flash.min.js"></script>
<script  src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script  src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.24/build/pdfmake.min.js"></script>
<script  src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.24/build/vfs_fonts.js"></script>
<script  src="//cdn.datatables.net/buttons/1.2.4/js/buttons.html5.min.js"></script>
<script  src="//cdn.datatables.net/buttons/1.2.4/js/buttons.print.min.js"></script>
<link rel="stylesheet"  href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css" />
<link rel="stylesheet"  href="https://cdn.datatables.net/buttons/1.2.4/css/buttons.dataTables.min.css" />
<script  src="//cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js"></script>

</head>

<body>
<?php

function checkValues($value)
{
	 // Use this function on all those values where you want to check for both sql injection and cross site scripting
	 //Trim the value
	 $value = trim($value);
	 
	// Stripslashes
	if (get_magic_quotes_gpc()) {
		$value = stripslashes($value);
	}
	
	 // Convert all &lt;, &gt; etc. to normal html and then strip these
	 $value = strtr($value,array_flip(get_html_translation_table(HTML_ENTITIES)));
	
	 // Strip HTML Tags
	 $value = strip_tags($value);
	
	// Quote the value
	$value = ($value);
	return $value;
	
}	

include("config.php");

$rec = checkValues($_REQUEST['val']);
//get table contents

if($rec)
{

	$sql = "select * from student_info where stu_aadhar_no like '%$rec%' ";
	
}

else

{

	$sql = "select * from student_info";

}



$rsd = mysqli_query($con,$sql) or die(mysqli_error($con));
$total =  mysqli_num_rows($rsd);

?>



<?php
echo "<h2>Search Result</h2>";
// echo "<table border='0'  id='content' cellspacing='0' cellpadding='0'>
// <tr bgcolor='#FFFFCC'>
// <th>Firstname</th>
// <th>Lastname</th>
// <th>Age</th>
// <th>Hometown</th>
// <th>Job</th>
// </tr>";
echo"<table width='100%' border='1' cellspacing='0' class='display nowrap table-bordered table-hover' id='example'>
        <thead>
            <tr>
            <th>Institute Name</th>
            <th>Aadhar No</th>
            <th>Student Name</th>
            <th>Caste</th>
            <th>DOB</th>
            <th>Registraion Date</th>
            <th>Action</th>
            </tr>
            
        </thead>
		
		
        <tbody>";

while ($row = mysqli_fetch_assoc($rsd))

{
  echo "<tr>";
  echo "<td>" . $row['c_name'] . "</td>";
  echo "<td>" . $row['stu_aadhar_no'] . "</td>";
  echo "<td>" . $row['stu_name'] . "</td>";
  echo "<td>" . $row['stu_caste'] . "</td>";
  echo "<td>" . $row['stu_dob'] . "</td>";
  echo "<td>" . $row['stu_reg_date'] . "</td>";
 ?>
 <td>
 	<?php
  	if($row['c_name']==$_SESSION['c_name'])
  	{
  		echo "Your Student";	
  	}
  	elseif($row['stu_status']=='Request')
  	{
  		echo "Already Request";
  	}
  	else
  	{
  		echo "<a class='btn btn-success' href='req.php?id=".$row['id']."&&c_name_transfer=".$_SESSION['c_name']."' >Request</a>";
  	}
  	?>
  </td>
  </tr>
 <?php } 
echo "</tbody></table>";



if($total==0)
{ 
	echo '<div class="no-rec">No Record Found !</div>';
}
?>

<script>
			
			
			$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
					  {
						"extend": "colvis",
						"text": "<i class='fa fa-search bigger-110 blue'></i> <span class='hidden'>Show/hide columns</span>",
						"className": "btn btn-white btn-primary btn-bold",
						columns: ':not(:first):not(:last)'
					  },
					  {
						"extend": "copy",
						"text": "<i class='fa fa-copy bigger-110 pink'></i> <span class='hidden'>Copy to clipboard</span>",
						"className": "btn btn-white btn-primary btn-bold"
					  },
					  {
						"extend": "csv",
						"text": "<i class='fa fa-database bigger-110 orange'></i> <span class='hidden'>Export to CSV</span>",
						"className": "btn btn-white btn-primary btn-bold"
					  },
					  {
						"extend": "excel",
						"text": "<i class='fa fa-file-excel-o bigger-110 green'></i> <span class='hidden'>Export to Excel</span>",
						"className": "btn btn-white btn-primary btn-bold"
					  },
					  {
						"extend": "pdf",
						"text": "<i class='fa fa-file-pdf-o bigger-110 red'></i> <span class='hidden'>Export to PDF</span>",
						"className": "btn btn-white btn-primary btn-bold"
					  },
					  {
						"extend": "print",
						"text": "<i class='fa fa-print bigger-110 grey'></i> <span class='hidden'>Print</span>",
						"className": "btn btn-white btn-primary btn-bold",
						autoPrint: false,
						message: 'This print was produced using the Print button for DataTables'
					  }
					 
        ]
    } );
	
} );
			</script>
			
			
</body>
</html>