<?php
include("start.php");
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>School/College Admin - Edit Documents</title>

		

		<?php
		
		include "header.php";
		
		?>
		
		
		
				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>
			</div>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								School/College
							</li>
							<li class="active">Dashboard</li>
						</ul><!-- /.breadcrumb -->

						<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>



	
						
					</div>

					<div class="page-content">
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>

							<div class="ace-settings-box clearfix" id="ace-settings-box">
								<div class="pull-left width-50">
									<div class="ace-settings-item">
										<div class="pull-left">
											<select id="skin-colorpicker" class="hide">
												<option data-skin="no-skin" value="#438EB9">#438EB9</option>
												<option data-skin="skin-1" value="#222A2D">#222A2D</option>
												<option data-skin="skin-2" value="#C6487E">#C6487E</option>
												<option data-skin="skin-3" value="#D0D0D0">#D0D0D0</option>
											</select>
										</div>
										<span>&nbsp; Choose Skin</span>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-navbar" autocomplete="off" />
										<label class="lbl" for="ace-settings-navbar"> Fixed Navbar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-sidebar" autocomplete="off" />
										<label class="lbl" for="ace-settings-sidebar"> Fixed Sidebar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-breadcrumbs" autocomplete="off" />
										<label class="lbl" for="ace-settings-breadcrumbs"> Fixed Breadcrumbs</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-rtl" autocomplete="off" />
										<label class="lbl" for="ace-settings-rtl"> Right To Left (rtl)</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-add-container" autocomplete="off" />
										<label class="lbl" for="ace-settings-add-container">
											Inside
											<b>.container</b>
										</label>
									</div>
								</div><!-- /.pull-left -->

								<div class="pull-left width-50">
									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-hover" autocomplete="off"/>
										<label class="lbl" for="ace-settings-hover"> Submenu on Hover</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-compact" autocomplete="off" />
										<label class="lbl" for="ace-settings-compact"> Compact Sidebar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-highlight" autocomplete="off" />
										<label class="lbl" for="ace-settings-highlight"> Alt. Active Item</label>
									</div>
								</div><!-- /.pull-left -->
							</div><!-- /.ace-settings-box -->
						</div><!-- /.ace-settings-container -->

						<div class="page-header">
							<h1>
								Document
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									Edit Student Document
								</small>
							</h1>
						</div><!-- /.page-header -->
<?php
if(isset($_GET['d_id']))
		{
		$query="select * from documents where d_id='".$_GET['d_id']."' ";

		$res=mysqli_query($con,$query) or die(mysqli_error($con));
		$row=mysqli_fetch_array($res);
		
		
?>	
								
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->				

								<form class="form-horizontal" role="form" method="post" enctype="multipart/form-data" >
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Name of Student </label>

										<div class="col-sm-9">									
											<input type="text" name="stu_name" id="form-field-2" placeholder="Enter Student Name" class="col-xs-10 col-sm-5" value="<?php echo $row['stu_name']; ?>" readonly required />	
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Aadhar Card No </label>

										<div class="col-sm-9">
											<input type="text" name="stu_aadhar_no" id="form-field-2" placeholder="Enter Aadhar Card No" maxlength="12" class="aad col-xs-10 col-sm-5" value="<?php echo $row['stu_aadhar_no']; ?>" readonly required /> 
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2"> Document Name </label>

										<div class="col-sm-9">
											<input type="text" name="doc_name" id="form-field-2" placeholder="Enter Document Name" class="col-xs-10 col-sm-5" value="<?php echo $row['doc_name']; ?>" required />										
										</div>
									</div>


									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2"> Document Description </label>

										<div class="col-sm-9">
											
											<textarea name="doc_description" id="form-field-2" placeholder="Enter Document Description" class="col-xs-10 col-sm-5" required ><?php echo $row['doc_description']; ?></textarea>
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2"> Document </label>

										<div class="col-sm-9">
											<a href="Student_Documents/<?php echo $row['doc_file']; ?>" class="btn btn-sm  btn-success" name="doc_file" download >Download</a>
										<!-- </div>
										
										<div class="col-sm-9"> -->
											<br><br>

											
											<input type="file" name="doc_file" id="form-field-2" placeholder="Select Document For Uploading" class="col-xs-10 col-sm-5"  />
										</div>
									</div>

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<button class="btn btn-info" type="submit" name="submit" >
												<i class="ace-icon fa fa-check bigger-110"></i>
												Submit
											</button>

											&nbsp; &nbsp; &nbsp;
											<!-- <button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button> -->
											<a href="javascript:history.back()" class="btn btn-danger"><i class="ace-icon fa fa-undo bigger-110"> Back</i></a>
										</div>
									</div>


								</form>
<?php

}

?>
								<?php 
								  		include "config.php";
										
										if(isset($_POST['submit']))
										{
											extract($_POST);
											
											// $img=md5(time());
										 //  	$name1=$_FILES['doc_file']['name'];
											// $type=$_FILES['doc_file']['type'];
											// $size=$_FILES['doc_file']['size'];
											// $temp=$_FILES['doc_file']['tmp_name'];
											// $img1="".$img.$name1;
											// move_uploaded_file($temp,"Student_Documents/".$img1);

					          				$name1=$_FILES['doc_file']['name'];
											$size=$_FILES['doc_file']['size'];
											$type=$_FILES['doc_file']['type'];

											$temp=$_FILES['doc_file']['tmp_name'];

											if($name1)
									        {
						                    $upload_dir = 'Student_Documents/';
						                    $imgExt = strtolower(pathinfo($name1,PATHINFO_EXTENSION)); // get image extension
						                    $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
						                    $doc_file = rand(1000,1000000).".".$imgExt;
						                    unlink($upload_dir.$row['doc_file']);
						                    move_uploaded_file($temp,$upload_dir.$doc_file);
									        }
									        else
									        {

									                    $doc_file=$row['doc_file'];           
									        }


											//$insert=mysqli_query($con,"insert into documents(c_email,c_name,stu_name,stu_aadhar_no,doc_name,doc_description,doc_file) values ('".$_SESSION['c_email']."','".$_SESSION['c_name']."','$stu_name','$stu_aadhar_no','$doc_name','$doc_description','$img1')") or die (mysqli_error($con));

									        $updateq='update documents set
									        		 	c_email="'.$_SESSION['c_email'].'",
									        		 	c_name="'.$_SESSION['c_name'].'",
									        		 	stu_name="'.$_POST['stu_name'].'",
									        		 	stu_aadhar_no="'.$_POST['stu_aadhar_no'].'",
									        		 	doc_name="'.$_POST['doc_name'].'",
									        		 	doc_description="'.$_POST['doc_description'].'",
									        		 	doc_file="'.$doc_file.'"
									        		 	 where d_id="'.$_GET['d_id'].'" ' ;
									        		 	
									       	 $upresult = mysqli_query($con,$updateq); 
											if($upresult)
											{											
											echo "<script>";
											echo "alert('Student Document Updated Successfully.');";
											echo "window.location.href='view_document.php';";
											echo "</script>";								
											}
											else
											{
											echo "<script>";
											echo 'alert("Document Not Updated");';
											echo "</script>";
											}
								
							
									}
								?>

								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
						<br>
						
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

		<?php

include ('profilefooter.php');

?>
	</body>
</html>
