<?php
$con=mysqli_connect("localhost","root","","aadhar_education");
?>