<?php
include("start.php");
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>School/College Admin - Dashboard</title>

		<!-- page specific plugin styles -->
		<link rel="stylesheet" href="assets/css/jquery-ui.custom.min.css" />
		<link rel="stylesheet" href="assets/css/chosen.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-datepicker3.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-timepicker.min.css" />
		<link rel="stylesheet" href="assets/css/daterangepicker.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-colorpicker.min.css" />
		

		<?php
		
		include "header.php";
		
		?>
		
		
		
				<div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
					<i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
				</div>
			</div>

			<div class="main-content">
				<div class="main-content-inner">
					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								School/College
							</li>
							<li class="active">Dashboard</li>
						</ul><!-- /.breadcrumb -->

						<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	
						
					</div>

					<div class="page-content">
						<div class="ace-settings-container" id="ace-settings-container">
							<div class="btn btn-app btn-xs btn-warning ace-settings-btn" id="ace-settings-btn">
								<i class="ace-icon fa fa-cog bigger-130"></i>
							</div>

							<div class="ace-settings-box clearfix" id="ace-settings-box">
								<div class="pull-left width-50">
									<div class="ace-settings-item">
										<div class="pull-left">
											<select id="skin-colorpicker" class="hide">
												<option data-skin="no-skin" value="#438EB9">#438EB9</option>
												<option data-skin="skin-1" value="#222A2D">#222A2D</option>
												<option data-skin="skin-2" value="#C6487E">#C6487E</option>
												<option data-skin="skin-3" value="#D0D0D0">#D0D0D0</option>
											</select>
										</div>
										<span>&nbsp; Choose Skin</span>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-navbar" autocomplete="off" />
										<label class="lbl" for="ace-settings-navbar"> Fixed Navbar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-sidebar" autocomplete="off" />
										<label class="lbl" for="ace-settings-sidebar"> Fixed Sidebar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-breadcrumbs" autocomplete="off" />
										<label class="lbl" for="ace-settings-breadcrumbs"> Fixed Breadcrumbs</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-rtl" autocomplete="off" />
										<label class="lbl" for="ace-settings-rtl"> Right To Left (rtl)</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2 ace-save-state" id="ace-settings-add-container" autocomplete="off" />
										<label class="lbl" for="ace-settings-add-container">
											Inside
											<b>.container</b>
										</label>
									</div>
								</div><!-- /.pull-left -->

								<div class="pull-left width-50">
									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-hover" autocomplete="off"/>
										<label class="lbl" for="ace-settings-hover"> Submenu on Hover</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-compact" autocomplete="off" />
										<label class="lbl" for="ace-settings-compact"> Compact Sidebar</label>
									</div>

									<div class="ace-settings-item">
										<input type="checkbox" class="ace ace-checkbox-2" id="ace-settings-highlight" autocomplete="off" />
										<label class="lbl" for="ace-settings-highlight"> Alt. Active Item</label>
									</div>
								</div><!-- /.pull-left -->
							</div><!-- /.ace-settings-box -->
						</div><!-- /.ace-settings-container -->

						<div class="page-header">
							<h1>
								Request Admission
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									Send Request
								</small>
							</h1>
						</div><!-- /.page-header -->

									<?php

										include "config.php";

										// if(isset($_POST['submit']))
										// {
										// 	extract($_POST);

											
										// }
									?>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
<script language="javascript">

$(document).ready(function(){
	//show loading bar
	function showLoader()
	{
		$('.search-background').fadeIn(200);
	}

	//hide loading bar
	function hideLoader()
	{
		$('#sub_cont').fadeIn(1500);
		$('.search-background').fadeOut(200);
	};


	$('#search').keyup(function(e)
	{
      if(e.keyCode == 13) 
      {
      	showLoader();
		$('#sub_cont').fadeIn(1500);
		$("#content #sub_cont").load("search.php?val=" + $("#search").val(), hideLoader());
      }
    });

	$(".searchBtn").click(function(){
		//show the loading bar
		showLoader();
		$('#sub_cont').fadeIn(1500);
		$("#content #sub_cont").load("search.php?val=" + $("#search").val(), hideLoader());
	});

});

</script>

								<!-- <form class="form-horizontal" role="form" > -->
									<h3>Student Aadhar Details</h3><br>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2">Aadhar No </label>

										<div class="col-sm-9">
											<input type="text" name="stu_aadhar_no" id="search" id="form-field-2" placeholder="Enter 12 Digit Student Aadhar No" class="col-xs-10 col-sm-5" maxlength="12" required />
											<!-- <span class="help-inline col-xs-12 col-sm-7">
												<span class="middle">Enter Report Name Here</span>
											</span> -->
										</div>
									</div>

<br>
<br>
									<!-- <div class="clearfix form-actions"> -->
										<div class="col-md-offset-3 col-md-9 searchBtn">
											<!-- <div class="searchBtn"> -->
											<button class="btn btn-info" name="submit" >
												<i class="ace-icon fa fa-check bigger-110"></i>
												Submit
											</button>
											<!-- </div> -->

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												Reset
											</button>
										</div>
									<!-- </div> -->


								<!-- </form> -->

	
								
						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->				
								<br clear="all" />
								<div id="content">

									<div class="search-background">
										<label><img src="loader.gif" alt="" /></label>
									</div>

									<div id="sub_cont">
										
											<?php ?>

									</div>

								</div>

								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
						<br>
						
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

		<?php

include ('footer_calender.php');

?>
	</body>
</html>
